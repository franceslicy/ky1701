# import all modules of the project

import score
import note
import reducer
import algorithm
import learning
